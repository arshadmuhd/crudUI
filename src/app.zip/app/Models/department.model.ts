export interface Department {
    id: string;
    departmentName: string;
    departmentStatus: boolean;
  }
  